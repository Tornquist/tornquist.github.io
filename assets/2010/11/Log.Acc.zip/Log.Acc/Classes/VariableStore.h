//
//  VariableStore.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/15/10.
//  Copyright 2010 Student. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VariableStore : NSObject
{
    // Place any "global" variables here
	double accelX;
	double accelY;
	double accelZ;
}
// message from which our instance is obtained
+ (VariableStore *)sharedInstance;
@end