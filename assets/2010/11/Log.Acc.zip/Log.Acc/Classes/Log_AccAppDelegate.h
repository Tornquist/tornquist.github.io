//
//  Log_AccAppDelegate.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright Student 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Log_AccViewController;

@interface Log_AccAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    Log_AccViewController *viewController;
	
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Log_AccViewController *viewController;


@end

