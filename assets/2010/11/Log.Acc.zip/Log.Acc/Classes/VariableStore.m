//
//  VariableStore.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/15/10.
//  Copyright 2010 Student. All rights reserved.
//

#import "VariableStore.h"


@implementation VariableStore

+ (VariableStore *)sharedInstance
{
    // the instance of this class is stored here
    static VariableStore *myInstance = nil;
	
    // check to see if an instance already exists
    if (nil == myInstance) {
        myInstance  = [[[self class] alloc] init];
        // initialize variables here
		accelX = 0.0;
		accelY = 0.0;
		accelZ = 0.0;
    }
    // return the instance of this class
    return myInstance;
}
@end
