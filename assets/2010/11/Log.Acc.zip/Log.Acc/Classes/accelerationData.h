//
//  accelerationData.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/21/10.
//  Copyright 2010 Student. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface accelerationData : NSObject {
	
}

@end
