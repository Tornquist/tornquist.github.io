//
//  SharedVariables.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/25/10.
//  Copyright 2010 Student. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SharedVariables : NSObject {
	NSMutableArray *arrayAccX;
	NSMutableArray *arrayAccY;
	NSMutableArray *arrayAccZ;

}

@property (nonatomic, retain) NSMutableArray *arrayAccX;
@property (nonatomic, retain) NSMutableArray *arrayAccY;
@property (nonatomic, retain) NSMutableArray *arrayAccZ;


+ (id)sharedManager;

@end