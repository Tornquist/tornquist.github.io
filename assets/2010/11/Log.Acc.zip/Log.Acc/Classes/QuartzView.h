//
//  QuartzView.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright 2010 Student. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface QuartzView : UIView
{
}

-(void)drawInContext:(CGContextRef)context;

@end