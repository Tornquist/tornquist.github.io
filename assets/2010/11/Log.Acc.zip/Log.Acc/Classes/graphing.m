//
//  graphing.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/15/10.
//  Copyright 2010 Student. All rights reserved.
//

#import "graphing.h"
#import "SharedVariables.h"

@implementation graphing

BOOL graphData;

double accelX;
double accelY;
double accelZ;


- (id)initWithFrame:(CGRect)frame {
	//self = [super init];
	
    if ((self = [super initWithFrame:frame])) {
        // Initialization code		
		
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
		
	
	
	if (graphData)
	{
		
		
		SharedVariables *manager = [SharedVariables sharedManager];
		
		////NSNumber *xValue = [NSNumber numberWithDouble:accelX];
		//[arrayAccX addObject: [NSString stringWithFormat:@"%f",accelX]];
		////[arrayAccX addObject: @"Hello"];
		CGContextRef context = UIGraphicsGetCurrentContext();
		CGContextSetLineWidth(context, 2.0);
		
		//198/2 = 99	
		
		//X Graphing
		int arrayCount = [manager.arrayAccX count];
		if (arrayCount != 0)
		{
			//NSLog(@"Not Null");
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat components[] = {1.0, 0.0, 0.0, 1.0};
			CGColorRef color = CGColorCreate(colorspace, components);
			CGContextSetStrokeColorWithColor(context, color);
			if ([manager.arrayAccX count]== 1)
			{
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccX objectAtIndex: 0] doubleValue])*66)));
				CGContextAddLineToPoint(context, 300 , (int)(99-(([[manager.arrayAccX objectAtIndex: 0] doubleValue])*66)));	
			}
			else {
				int arraySize = [manager.arrayAccX count];
				double spacing = (300.0/(arraySize-1));
				
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccX objectAtIndex: 0] doubleValue])*66)));
				for (int i = 1; i < arraySize; i++)
				{
					CGContextAddLineToPoint(context, ((int)(i*spacing)) , (int)(99-(([[manager.arrayAccX objectAtIndex: i] doubleValue])*66)));
				}
			}
			
			CGContextStrokePath(context);
			CGColorSpaceRelease(colorspace);
			CGColorRelease(color);

		}
		
		//Y Graphing
		arrayCount = [manager.arrayAccY count];
		if (arrayCount != 0)
		{
			//NSLog(@"Not Null");
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat components[] = {0.0, 1.0, 0.0, 1.0};
			CGColorRef color = CGColorCreate(colorspace, components);
			CGContextSetStrokeColorWithColor(context, color);
			if ([manager.arrayAccY count]== 1)
			{
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccY objectAtIndex: 0] doubleValue])*66)));
				CGContextAddLineToPoint(context, 300 , (int)(99-(([[manager.arrayAccY objectAtIndex: 0] doubleValue])*66)));	
			}
			else {
				int arraySize = [manager.arrayAccY count];
				double spacing = (300.0/(arraySize-1));
				
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccY objectAtIndex: 0] doubleValue])*66)));
				for (int i = 1; i < arraySize; i++)
				{
					CGContextAddLineToPoint(context, ((int)(i*spacing)) , (int)(99-(([[manager.arrayAccY objectAtIndex: i] doubleValue])*66)));
				}
			}
			
			CGContextStrokePath(context);
			CGColorSpaceRelease(colorspace);
			CGColorRelease(color);
			
		}
		//Z Graphing
		arrayCount = [manager.arrayAccZ count];
		if (arrayCount != 0)
		{
			//NSLog(@"Not Null");
			CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
			CGFloat components[] = {0.0, 0.0, 1.0, 1.0};
			CGColorRef color = CGColorCreate(colorspace, components);
			CGContextSetStrokeColorWithColor(context, color);
			if ([manager.arrayAccZ count]== 1)
			{
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccZ objectAtIndex: 0] doubleValue])*66)));
				CGContextAddLineToPoint(context, 300 , (int)(99-(([[manager.arrayAccZ objectAtIndex: 0] doubleValue])*66)));	
			}
			else {
				int arraySize = [manager.arrayAccZ count];
				double spacing = (300.0/(arraySize-1));
				
				CGContextMoveToPoint(context, 0 , (int)(99-(([[manager.arrayAccZ objectAtIndex: 0] doubleValue])*66)));
				for (int i = 1; i < arraySize; i++)
				{
					CGContextAddLineToPoint(context, ((int)(i*spacing)) , (int)(99-(([[manager.arrayAccZ objectAtIndex: i] doubleValue])*66)));
				}
			}
			
			CGContextStrokePath(context);
			CGColorSpaceRelease(colorspace);
			CGColorRelease(color);
			
		}
		 
	}
	
}


- (void)dealloc {
    [super dealloc];
}


@end
