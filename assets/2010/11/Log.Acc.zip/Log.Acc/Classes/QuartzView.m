//
//  QuartzView.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright 2010 Student. All rights reserved.
//
#import "QuartzView.h"


@implementation QuartzView

-(id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if(self != nil)
	{
		self.backgroundColor = [UIColor clearColor];
		self.opaque = NO;
		self.clearsContextBeforeDrawing = NO;
	}
	return self;
}

-(void)drawInContext:(CGContextRef)context
{
	//CGContextRef context = UIGraphicsGetCurrentContext();
	
	CGContextSetLineWidth(context, 2.0);
	CGContextSetStrokeColor(context, [UIColor redColor].CGColor);
	CGContextMoveToPoint(context, 100.0f, 100.0f);
	CGContextAddLineToPoint(context, 200.0f, 200.0f);
	CGContextStrokePath(context);
}

-(void)drawRect:(CGRect)rect
{
	//[self drawInContext:UIGraphicsGetCurrentContext()];
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSetLineWidth(context, 2.0);
	CGContextSetStrokeColor(context, [UIColor redColor].CGColor);
	CGContextMoveToPoint(context, 100.0f, 100.0f);
	CGContextAddLineToPoint(context, 200.0f, 200.0f);
	CGContextStrokePath(context);
}

@end
