//
//  graphing.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/15/10.
//  Copyright 2010 Student. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface graphing : UIView 
{
}

@end
