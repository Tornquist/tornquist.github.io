//
//  TransparentDrawingView.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright 2010 Student. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface TransparentDrawingView : NSObject {

}

@end
