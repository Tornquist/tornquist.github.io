//
//  SharedVariables.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/25/10.
//  Copyright 2010 Student. All rights reserved.
//

#import "SharedVariables.h"

static SharedVariables *sharedMyManager = nil;

@implementation SharedVariables

@synthesize arrayAccX;
@synthesize arrayAccY;
@synthesize arrayAccZ;

#pragma mark Singleton Methods
+ (id)sharedManager {
    @synchronized(self) {
        if(sharedMyManager == nil)
            sharedMyManager = [[super allocWithZone:NULL] init];
    }
    return sharedMyManager;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedManager] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; //denotes an object that cannot be released
}
- (void)release {
    // never release
}
- (id)autorelease {
    return self;
}
- (id)init {
    if (self = [super init]) {
		arrayAccX = [[NSMutableArray alloc] init]; 
		arrayAccY = [[NSMutableArray alloc] init];
		arrayAccZ = [[NSMutableArray alloc] init];
    }
    return self;
}
- (void)dealloc {
    // Should never be called, but just here for clarity really.
	[arrayAccX release];
    [super dealloc];
}

@end