//
//  Log_AccViewController.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright Student 2010. All rights reserved.
//

#import "Log_AccViewController.h"
#import "SharedVariables.h"

@implementation Log_AccViewController

@synthesize graph;

@synthesize buttonText;

@synthesize labelX;
@synthesize labelY;
@synthesize labelZ;
@synthesize accelerometer;


BOOL graphData = NO;


BOOL isGraphing = false;
double accelX = 0.0;
double accelY = 0.0;
double accelZ = 0.0;

int graphStep = 0;




//BOOL graphData = false;
//int timePosition = 0;


- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration{
	labelX.text = [NSString stringWithFormat:@"%@%f", @"X: ", acceleration.x];
	labelY.text = [NSString stringWithFormat:@"%@%f", @"Y: ", acceleration.y];
	labelZ.text = [NSString stringWithFormat:@"%@%f", @"Z: ", acceleration.z];

	//self->accelX = (double) acceleration.x;
	accelX = acceleration.x;
	accelY = acceleration.y;
	accelZ = acceleration.z;
		
	if (graphData)
	{		
		//Add Data to List
		SharedVariables *manager = [SharedVariables sharedManager];
		[manager.arrayAccX addObject:[NSNumber numberWithDouble:accelX]];
		[manager.arrayAccY addObject:[NSNumber numberWithDouble:accelY]];
		[manager.arrayAccZ addObject:[NSNumber numberWithDouble:accelZ]];
		
		[graph setNeedsDisplay];
	}
						 
}



- (IBAction)startClick:(id)sender
{	
	if (isGraphing == false)
	{
		//Clear Saved Data in List
		
		
		SharedVariables *manager = [SharedVariables sharedManager];
		[manager.arrayAccX removeAllObjects];
		[manager.arrayAccY removeAllObjects];
		[manager.arrayAccZ removeAllObjects];
		
		[buttonText setTitle:@"Stop Test" forState:UIControlStateNormal];
		isGraphing = true;
		graphStep = 0;
		
		graphData = YES;
		
	}
	else {
		
		
		[buttonText setTitle: @"Start Test" forState:UIControlStateNormal];
		isGraphing = false;
		
		graphData = NO;
	}
		
	
}



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	
	self.accelerometer = [UIAccelerometer sharedAccelerometer];
	self.accelerometer.updateInterval = (1/30);
	self.accelerometer.delegate = self;
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
