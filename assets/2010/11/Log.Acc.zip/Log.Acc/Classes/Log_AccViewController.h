//
//  Log_AccViewController.h
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright Student 2010. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Log_AccViewController : UIViewController <UIAccelerometerDelegate>{
	
	IBOutlet UIButton *buttonText;
	
	IBOutlet UILabel *labelX;
	IBOutlet UILabel *labelY;
	IBOutlet UILabel *labelZ;
	
	IBOutlet UIView *graph;
	
	UIAccelerometer *accelerometer;
		
}


@property (nonatomic, retain) UIButton *buttonText;

- (IBAction)startClick:(id)sender;

@property (nonatomic, retain) IBOutlet UIView *graph;

@property (nonatomic, retain) IBOutlet UILabel *labelX;
@property (nonatomic, retain) IBOutlet UILabel *labelY;
@property (nonatomic, retain) IBOutlet UILabel *labelZ;

@property (nonatomic, retain) UIAccelerometer *accelerometer; 


@end

