//
//  accelerationData.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/21/10.
//  Copyright 2010 Student. All rights reserved.
//

#import "accelerationData.h"


@implementation accelerationData

double accelerationX;
double accelerationY;
double accelerationZ;

-(void)setAcceleration:(double *) accelerX: (double *) accelerY:(double *) accelerZ {
	accelerationX = accelerX;
	accelerationY = accelerY;
	accelerationZ = accelerZ;
}

-(double)getX {
	return accelerationX;
}

-(double)getY {
	return accelerationY;
}

-(double)getZ {
	return accelerationZ;
}


@end
