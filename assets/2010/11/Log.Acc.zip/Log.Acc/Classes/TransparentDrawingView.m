//
//  TransparentDrawingView.m
//  Log.Acc
//
//  Created by Nathan Tornquist on 11/13/10.
//  Copyright 2010 Student. All rights reserved.
//

#import "TransparentDrawingView.h"


@implementation TransparentDrawingView

- (void)initObject {
    // Initialization code
    [super setBackgroundColor:[UIColor clearColor]];
}
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
        [self initObject];
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aCoder {
    if (self = [super initWithCoder:aCoder]) {
        // Initialization code
        [self initObject];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    // Drawing code
	
    // Draw a line from 'fromPoint' to 'toPoint'
}

@end