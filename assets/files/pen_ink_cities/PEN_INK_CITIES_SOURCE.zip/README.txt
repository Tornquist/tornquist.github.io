Pen and Ink NPR of Cities
CS 334/ECE 30834, Fall 2013
Nathan Tornquist - Final Project

------------------------------------------------
------------------------------------------------
------------------------------------------------
------------------------------------------------

Project Goals:

1) Create a set of textures and logic to render
objects in a pen and ink style.  To have a 
variety of textures for varying light conditions
and materials for a more realistic appearance.
In addition to the textures, develop an algorithm
to determine the edges of buildings and materials
to create an ink-like tracing.

2) To procedurally render cities from a *.txt file.
The logic will take in a floorplan and based on
floor height ranges and a floor "fallout" pattern,
renger a variety of buildings. The logic supports a
grid pattern and multiple building descriptions.  

------------------------------------------------
------------------------------------------------
------------------------------------------------
------------------------------------------------

Disk Contents:

Within the root folder of this disk you will find 
two folders, and one *.pptx file.  The powerpoint
file is the presentation used during the final 
demonstration of this project. The other two folders
contain the source and a compiled *.exe file.  To
demo the program navigate to EXE and select 
finalProject.exe

If you wish to view the source navigate to Source
open the project file within Visual Studio.  

Within data-files/examples pre-rendered building 
object files exist, as well as the logic used to
generate them.  The file names of the paired files
match.  To view these, the compiled project is faster,
but the visual studio project has access to the
examples as well.


------------------------------------------------
------------------------------------------------
------------------------------------------------
------------------------------------------------

Creating New Buildings

When "Reload Model" is selected within this project
the building.obj file from within data-files/ will 
be reloaded.

When "Rebuild Model" is selected, the logic from 
building.txt will be read, and building.obj will be
rewritten with the new city design.  The new city
will then be loaded and displayed within the program. 

To generate new buildings, see the example building.txt
file below:


------------------------------------------------
------------------------------------------------
------------------------------------------------
------------------------------------------------

---Begin File Template---

WORLD
WorldWidth(In Blocks)  WidthOfWorldBlock
WorldHeight(In Blocks) HeightOfWorldBlock

BUILDING
BuildingWidth  #FrontWindows #BackWindows
BuildingHeight #LeftWindows  #RightWindows
MinFloors MaxFloors
F [Fallout Pattesns]
R [Rotation Patterns]

---End File Template---

The R, WORLD, and BUILDING labels are required.

-----------------------

R is followed by a list of rotation/footprint actions.

The world is designed in a grid as seen blow:

|--------|
|2      1|
|    5   |
|3      4|
|--------|

The + direction is counterclockwise.
The - direction is clockwise.

Each building starts with one block.  

To specify the floorplan of a building, simply write
the pattern of actions that needs to occur.  +1 will 
rotate the current block on the top right corner in 
the counterclockwise direction, which will cause a new
block to be formed directly to the right of original
block.  The next command given will be based on the
newly created block.  +2 would rotate counterclockwise
on the top left corner and create a block above the
current one.

The instruction +1 +2 on the original block would
create:

          |--------|
          |2      1|
          |    5   |
          |3      4|
          |--------|
|--------||--------|
|2      1||2      1|
|    5   ||    5   |
|3      4||3      4|
|--------||--------|

5 causes the block to rotate in the middle, and is of
little use with square building units. Square units
are not required though.  They are specified immediatly
after the "BUILDING" tag.

A block always is labeled with the numbers shown above.

[ +2 20 ] is shorthand notation.  It will apply a rotation
in the +2 direction 20 times.

Every time a rotation occurs, a new element is added to a list.
If a rotation pattern occurs an element to pass directly over
another element, the later element will be removed from the
list is the corners are in exactly the same place.

The beginning of the list is the original block, and the
end is the final block created.  Those points are useful when
specifying a fallout pattern.

-----------------------

F is followed by a list of fallout patterns.
These patterns are floors that can lose building
units after the first story of the building was 
constructed.  A lost unit will not appear at a later
floor.  The building's style is set with the F patterns.

-4 means remove four elements from the end of the 
   specified rotation pattern.
+4 means remove four elements from the beginning 
   of the specified rotation pattern.
.04 means remove four elements from the beginning
   and end of the specified rotation pattern.

Fallout rates can also be random.
A [ followed by a symbol
	-end of footprint/rotation pattern
	+beginning of footprint/rotation pattern
	.both ends of footprint/rotation pattern
	|both ends, random for both
The third symbol is the min value, the fourth is the
max.  A fifth number can be provided if the fallout
should be repeated.  The number provided is the number
of times to repeat it.  Finally, the entry is closed with
a ].  

Example: [ | 0 3 5 ] -- This entry randomly removes 
between 0 and 3 elements from the beginning and end 
of the building rotation pattern five times. 
(Rule applied for five different floors)

If a fallout pattern is specified, the F is needed. 
No fallout pattern is required. 


-----------------------

---Full Example File---
WORLD
3 50
3 50

BUILDING
10 3 3
10 3 3
10 20
F [ + 0 3 3 ]
R [ +2 3 ] [ +3 3 ] [ +4 3 ] [ +1 2 ]

BUILDING
10 3 3
10 3 3
10 30
F 0 0 4 0 4 0 4
R -2 -1 +1 +2 +2 +3 +4 +3 +2 +3 +4 +4 +4 +1 +2
---End Example File----