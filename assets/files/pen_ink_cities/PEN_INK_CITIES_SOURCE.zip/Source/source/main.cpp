/**

  Example of using G3D shaders and GUIs.
  
  Template by Daniel Aliaga (aliaga@cs.purdue.edu), based on PixelShader demo program.
  by Morgan McGuire, http://graphics.cs.williams.edu
 */
#include <G3D/G3DAll.h>
#include <GLG3D/GLG3D.h>
#include <math.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <time.h>
using namespace std;

class App : public GApp {
private:
    shared_ptr<ArticulatedModel>         model;

    LocalLightingEnvironment             environment;
	Texture::Ref                         bumpMap;
	Texture::Ref                         displacementMap;
	Texture::Ref                         modulationMap;

	Texture::Ref                         vert1;	
	Texture::Ref                         vert2;	
	Texture::Ref                         vert3;	
	Texture::Ref                         brick0;	
	Texture::Ref                         brick1;
	Texture::Ref                         brick2;
	Texture::Ref                         brick3;
	Texture::Ref                         brick4;
	Texture::Ref                         road;
	
	Texture::Ref                         roof0;	
	Texture::Ref                         roof1;
	Texture::Ref                         roof2;
	Texture::Ref                         roof3;
	Texture::Ref                         roof4;

	Texture::Ref                         glass0;	
	Texture::Ref                         glass1;
	Texture::Ref                         glass2;
	Texture::Ref                         glass3;
	Texture::Ref                         glass4;
    
    float                                diffuseScalar;
    int                                  diffuseColorIndex;

    float                                specularScalar;
    int                                  specularColorIndex;

    float                                reflect;
    float                                shine;
    float                                bumpiness;
	int edgeThresh;
	bool								 showTextures;
	bool								 showEdges;
    ////////////////////////////////////
    // GUI

    /** For dragging the model */
    shared_ptr<ThirdPersonManipulator>   manipulator;
    Array<GuiText>                       colorList;
	Array<string>					     buildingList;
	int								     buildingExample;

    void makeGui();
    void makeColorList();
	void makeBuildingList();
    void makeLighting();
    void loadTextures();
    void configureShaderArgs(Args& args);

public:

    App(const GApp::Settings& settings) : GApp(settings), diffuseScalar(0.6f), specularScalar(0.0f), reflect(0.0f), shine(20.0f), bumpiness(0.0f),edgeThresh(200),showTextures(true),showEdges(true),buildingExample(0) {}
	struct fileData;
	struct listItem;
	struct baseUnit;
	struct worldData;
	struct buildingData;
    virtual void onInit();
	virtual void GenerateBuilding();
	virtual fileData ReadFile(string path);
	virtual baseUnit * GenerateFootprint(buildingData data);
	virtual void RenderShape(App::buildingData data, string outPath, int widthOffset, int heightOffset);
	virtual void RemoveDuplicates(baseUnit * unit);
	virtual Vector2 FindCenter(baseUnit unit);
    virtual void onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D);
	virtual void Refresh();
	virtual void MakeGround(string outPath, float x1, float x2, float y1, float y2);
	virtual void LoadModel();
	virtual void LoadExample();
};

struct App::listItem{
	int intVal;
	float floatVal;
	float floatVal2;
	listItem * next;
};

struct App::worldData {
	int blockWidth;
	int blockHeight;
	int worldWidth;
	int worldHeight;
};



struct App::buildingData {
	int width;
	int height;

	int frontWindows;
	int backWindows;
	int leftWindows;
	int rightWindows;

	int floorMin;
	int floorMax;
	App::listItem * rate;
	App::listItem * rotation;
	App::baseUnit * footprint;
	App::buildingData * next;
};

struct App::baseUnit {
	Vector2 topL;
	Vector2 topR;
	Vector2 botL;
	Vector2 botR;
	Vector2 cent;
	App::baseUnit * next;
};

struct App::fileData {
	App::buildingData building;
	App::worldData world;
};

App::fileData App::ReadFile(string path)
{
	App::fileData retVal;

	ifstream file(path);
	string garbage;

	file >> garbage; //GRAB WORLD VARIABLE
	file >> retVal.world.worldWidth;
	file >> retVal.world.blockWidth;

	file >> retVal.world.worldHeight;
	file >> retVal.world.blockHeight;
	
	file >> garbage; //GRAB BUILDING VARIABLE
	file >> retVal.building.width;
	file >> retVal.building.frontWindows;
	file >> retVal.building.backWindows;
	file >> retVal.building.height;
	file >> retVal.building.leftWindows;
	file >> retVal.building.rightWindows;
	file >> retVal.building.floorMin;
	file >> retVal.building.floorMax;
	retVal.building.rotation = NULL;
	retVal.building.rate = NULL;
	retVal.building.next = NULL;
	listItem * nextRot = NULL;
	listItem * nextRate = NULL;

	App::buildingData * building = &retVal.building;
	
	string s;
	int state = 0;
	while(file >> s)
	{
		if (s.compare("F") == 0)
		{
			state = 1; // FallOut Rate
		}
		else if (s.compare("R") == 0)
		{
			state = 2; //Rotation Pattern State
		}
		else if (s.compare("BUILDING") == 0)
		{
			//NEW BUILDING
			App::buildingData * newBuilding = new buildingData();
			building->next = newBuilding;
			building = building->next;
			file >> building->width;
			file >> building->frontWindows;
			file >> building->backWindows;
			file >> building->height;
			file >> building->leftWindows;
			file >> building->rightWindows;
			file >> building->floorMin;
			file >> building->floorMax;
			building->rotation = NULL;
			building->rate = NULL;
			building->next = NULL;
			nextRot = NULL;
			nextRate = NULL;
		}
		else if (s.compare("[") == 0)
		{
			if (state == 1) //IF NOT SOMETHING IS BROKEN
			{
				listItem * newItem = new listItem();
				file >> s;
				if (s.compare(".") == 0)
				{
					newItem->intVal = 1;
				}
				else if (s.compare("+") == 0)
				{
					newItem->intVal = 2;
				}
				else if (s.compare("-") == 0)
				{
					newItem->intVal = 3;
				}
				else if (s.compare("|") == 0)
				{
					newItem->intVal = 4;
				}
				file >> newItem->floatVal;
				file >> newItem->floatVal2;
				file >> s;//Throw away close bracket
				newItem->next = NULL;
				
				if (building->rate == NULL)
				{
					building->rate = newItem;
					nextRate = newItem;
				}
				else
				{
					nextRate -> next = newItem;
					nextRate = newItem;
				}

				if (s.compare("]") != 0) //You have a repeat marker
				{
					int repeat = atoi(s.c_str());
					int intVal = newItem->intVal;
					float floatVal = newItem->floatVal;
					float floatVal2 = newItem->floatVal2;

					while (repeat > 1)
					{
						listItem * newItem2 = new listItem();
						newItem2->intVal = intVal;
						newItem2->floatVal = floatVal;
						newItem2->floatVal2 = floatVal2;
						newItem2->next = NULL;
						nextRate -> next = newItem2;
						nextRate = newItem2;
						repeat = repeat - 1;
					}
					file >> s; //Eat true end bracket
				}
			}

			else if (state == 2)
			{
				file >> s;
				int tempCount = 0;
				file >> tempCount;
				
				 //Throw Away closing bracket
				while (tempCount > 0)
				{
					listItem * newItem = new listItem();
					if (s.length() == 2)
					{
						if (s[0] == '+')
						{
							newItem->floatVal = 1;
						}
						else if(s[0] == '-')
						{
							newItem->floatVal = -1;
						}
						s = s[1];
					}
					else
					{
						newItem->floatVal = 1;
					}

					newItem->intVal = atoi(s.c_str());
					newItem->next = NULL;
				
					if (building->rotation == NULL)
					{
						building->rotation = newItem;
						nextRot = newItem;
					}
					else
					{
						nextRot -> next = newItem;
						nextRot = newItem;
					}
					tempCount = tempCount - 1;
				}
				file >> s;//Throw away closing bracket
			}
		}
		else
		{
			if (state == 1)
			{
				listItem * newItem = new listItem();
				newItem->floatVal = atof(s.c_str());
				newItem->floatVal2 = 0;
				newItem->intVal = 0;				
				newItem->next = NULL;
				
				if (building->rate == NULL)
				{
					building->rate = newItem;
					nextRate = newItem;
				}
				else
				{
					nextRate -> next = newItem;
					nextRate = newItem;
				}
			}
			else if (state == 2)
			{
				listItem * newItem = new listItem();
				if (s.length() == 2)
				{
					if (s[0] == '+')
					{
						newItem->floatVal = 1;
					}
					else if(s[0] == '-')
					{
						newItem->floatVal = -1;
					}
					s = s[1];
				}
				else
				{
					newItem->floatVal = 1;
				}

				newItem->intVal = atoi(s.c_str());
				newItem->next = NULL;
				
				if (building->rotation == NULL)
				{
					building->rotation = newItem;
					nextRot = newItem;
				}
				else
				{
					nextRot -> next = newItem;
					nextRot = newItem;
				}
			}
		}
	}

	file.close();

	return retVal;
}

Vector2 App::FindCenter(App::baseUnit unit)
{
	Vector2 retVal;
	retVal.x = (unit.topL.x + unit.topR.x)/2;
	retVal.y = (unit.topL.y + unit.botR.y)/2;
	return retVal;
}

App::baseUnit * App::GenerateFootprint(App::buildingData data)
{
	App::baseUnit * retVal = new baseUnit();
	retVal->next = NULL;
	retVal->topL = Vector2(-data.width/2,data.height/2);
	retVal->topR = Vector2(data.width/2,data.height/2);
	retVal->botL = Vector2(-data.width/2,-data.height/2);
	retVal->botR = Vector2(data.width/2,-data.height/2);
	retVal->cent = FindCenter(*retVal);

	listItem * item;
	item = data.rotation;
	Vector2 offset;

	baseUnit * lastUnit;
	lastUnit = retVal;

	Matrix2 rotR = Matrix2(0,1,-1,0);
	Matrix2 rotL = Matrix2(0,-1,1,0);

	Vector2 temp1, temp2, temp3, temp4;

	while (item != NULL)
	{
		baseUnit * unit = new baseUnit();
		switch(item->intVal)
		{
		case 1:
			offset = lastUnit->topL;
			break;
		case 2:
			offset = lastUnit->topR;
			break;
		case 3:
			offset = lastUnit->botR;
			break;
		case 4:
			offset = lastUnit->botL;
			break;
		case 5:
			offset = lastUnit->cent;
			break;
		}
		unit->botL = lastUnit->botL - offset;
		unit->botR = lastUnit->botR - offset;
		unit->topL = lastUnit->topL - offset;
		unit->topR = lastUnit->topR - offset;

		if (item->floatVal > 0)
		{
			temp1 = rotR*unit->botL;
			temp2 = rotR*unit->botR;
			temp3 = rotR*unit->topL;
			temp4 = rotR*unit->topR;

			unit->topL = temp1;
			unit->botL = temp2;
			unit->topR = temp3;
			unit->botR = temp4;
		}
		else
		{
			temp1 = rotL*unit->botL;
			temp2 = rotL*unit->botR;
			temp3 = rotL*unit->topL;
			temp4 = rotL*unit->topR;

			unit->botR = temp1;
			unit->topR = temp2;
			unit->botL = temp3;
			unit->topL = temp4;
		}

		unit->botL+=offset;
		unit->botR+=offset;
		unit->topL+=offset;
		unit->topR+=offset;
		unit->cent = FindCenter(*unit);

		unit->next = NULL;
		lastUnit->next = unit;
		lastUnit = unit;

		item = item->next;
	}
	

	return retVal;
}

void App::RemoveDuplicates(App::baseUnit * unit)
{
	baseUnit * curr;
	baseUnit * next;
	baseUnit * prev;
	curr = unit;
	next = unit->next;
	while (curr != NULL)
	{
		prev = curr;
		while(next != NULL)
		{
			
			if (curr->botL == next->botL && curr->botR == next->botR && curr->topL == next->topL && curr->topR == next->topR)
			{
				prev->next = next->next;
				next = prev->next;
			}
			else
			{
				prev = next;
				next = next->next;
			}
		}
		curr = curr->next;
		if (curr != NULL)
			next = curr->next;
	}
}

void App::MakeGround(string outPath, float x1, float y1, float x2, float y2)
{
	fstream file(outPath,std::fstream::out | std::fstream::app);
	file << "v " << x1 << " 0 " << y1 << endl; // -1
	file << "v " << x2 << " 0 " << y1 << endl; // -2
	file << "v " << x2 << " 0 " << y2 << endl; // -3
	file << "v " << x1 << " 0 " << y2 << endl; // -4
	file << "vn 0 7 0" << endl;
	file << "vt 1 1" << endl; // -4
	file << "vt 0 1" << endl; // -3
	file << "vt 0 0" << endl; // -2
	file << "vt 1 0" << endl; // -1
	file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
	
	file.close();
}

void App::RenderShape(App::buildingData data, string outPath, int widthOffset, int heightOffset)
{
	fstream file(outPath,std::fstream::out | std::fstream::app);
	baseUnit * original = data.footprint;
	baseUnit * footprint = data.footprint;
	int i = 1;
	int footprintCount = 0;
	int footprintPos = 0;
	srand(time(NULL));
	int max = 5;
	int texture = (rand() % (int)(max + 1));
	texture = pow(10,texture);
	//texture = 1;

	int floors = (rand() % (int)((data.floorMax-data.floorMin)+1)) + data.floorMin;

	int fallOutCount = 0;
	listItem * rate = data.rate;
	while (rate != NULL)
	{
		fallOutCount = fallOutCount + 1;
		rate = rate->next;
	}
	rate = data.rate;

	srand(time(NULL));
	int randFall = 10;
	int floorThreshold = (fallOutCount*100)/floors;
	
	randFall = (rand() % (int) 30);

	while (floors >= i)
	{
		footprintPos = 0;
		while(footprint != NULL && (footprintCount != 0 || i == 1))
		{
#pragma region renderbox
		//Top
		file << "v " << footprint->topL.x + widthOffset << " " << i*3 << " " << footprint->topL.y + heightOffset << endl; // -4
		file << "v " << footprint->botL.x + widthOffset << " " << i*3 << " " << footprint->botL.y + heightOffset << endl; // -3
		file << "v " << footprint->botR.x + widthOffset << " " << i*3 << " " << footprint->botR.y + heightOffset << endl; // -2
		file << "v " << footprint->topR.x + widthOffset << " " << i*3 << " " << footprint->topR.y + heightOffset << endl; // -1
		file << "vn 0 " << 5*texture << " 0" << endl;
		file << "vt 0 0" << endl; // -4
		file << "vt 0 " << abs(footprint->botL.x - footprint->botR.x)/3 << endl; // -3
		file << "vt " << abs(footprint->botL.y - footprint->topL.y)/3 << " " << abs(footprint->botL.x - footprint->botR.x)/3 << endl; // -2
		file << "vt " << abs(footprint->botL.y - footprint->topL.y)/3 << " 0" << endl; // -1
		file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;

		//Left
		file << "v " << footprint->topL.x + widthOffset << " " << i*3 << " " << footprint->topL.y + heightOffset << endl; // -4
		file << "v " << footprint->topL.x + widthOffset << " " << (i-1)*3 << " " << footprint->topL.y + heightOffset << endl; // -4
		file << "v " << footprint->botL.x + widthOffset << " " << (i-1)*3 << " " << footprint->botL.y + heightOffset << endl; // -3
		file << "v " << footprint->botL.x + widthOffset << " " << i*3 << " " << footprint->botL.y + heightOffset << endl; // -3
		file << "vn "<< -4*texture << " 0 0" << endl;
		file << "vt 0 0" << endl; // -4
		file << "vt 0 1" << endl; // -3
		file << "vt " << abs(footprint->botL.y - footprint->topL.y)/3 << " 1" << endl; // -2
		file << "vt " << abs(footprint->botL.y - footprint->topL.y)/3 << " 0" << endl; // -2
//			file << "f -4/-4/-1 -3/-3/-1 -2/-2/-1 -1/-1/-1" << endl;
		file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			
		if (data.leftWindows != 0)
		{
			int length = abs(footprint->botR.y - footprint->topR.y) - 2;
			float segment = (float)length/(float)data.leftWindows - (data.leftWindows-1)*(1.0/data.leftWindows);

			for (int j = 0; j < data.leftWindows; j++)
			{
				file << "v " << footprint->botL.x-.1 + widthOffset << " " << i*3-.5 << " " << (footprint->topL.y-1)-segment*(j)-j + heightOffset << endl; // -2
				file << "v " << footprint->botL.x-.1 + widthOffset << " " << (i-1)*3+.5 << " " << (footprint->topL.y-1)-segment*(j)-j + heightOffset << endl; // -2
				file << "v " << footprint->topL.x-.1 + widthOffset << " " << (i-1)*3+.5 << " " << (footprint->topL.y-1)-segment*(j+1)-j + heightOffset << endl; // -1
				file << "v " << footprint->topL.x-.1 + widthOffset << " " << i*3-.5 << " " << (footprint->topL.y-1)-segment*(j+1)-j + heightOffset << endl; // -1
				file << "vn -6 0 0" << endl;
				file << "vt 0 0" << endl; // -4
				file << "vt 0 1" << endl; // -3
				file << "vt " << abs(footprint->botL.y - footprint->topL.y)/(3*data.leftWindows) << " 1" << endl; // -2
				file << "vt " << abs(footprint->botL.y - footprint->topL.y)/(3*data.leftWindows) << " 0" << endl; // -2
				file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			}
		}

		//Right		
		file << "v " << footprint->botR.x + widthOffset << " " << i*3 << " " << footprint->botR.y + heightOffset << endl; // -2
		file << "v " << footprint->botR.x + widthOffset << " " << (i-1)*3 << " " << footprint->botR.y + heightOffset << endl; // -2
		file << "v " << footprint->topR.x + widthOffset << " " << (i-1)*3 << " " << footprint->topR.y + heightOffset << endl; // -1
		file << "v " << footprint->topR.x + widthOffset << " " << i*3 << " " << footprint->topR.y + heightOffset << endl; // -1
		file << "vn " << 1*texture << " 0 0" << endl;
		file << "vt 0 0" << endl; // -4
		file << "vt 0 1" << endl; // -3
		file << "vt " << abs(footprint->topR.y - footprint->botR.y)/3 << " 1" << endl; // -2
		file << "vt " << abs(footprint->topR.y - footprint->botR.y)/3 << " 0" << endl; // -2
		file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;

		if (data.rightWindows != 0)
		{
			int length = abs(footprint->botR.y - footprint->topR.y) - 2;
			float segment = (float)length/(float)data.rightWindows - (data.rightWindows-1)*(1.0/data.rightWindows);

			for (int j = 0; j < data.rightWindows; j++)
			{
				file << "v " << footprint->botR.x+.1 + widthOffset << " " << i*3-.5 << " " << (footprint->topR.y-1)-segment*(j+1)-j + heightOffset << endl; // -2
				file << "v " << footprint->botR.x+.1 + widthOffset << " " << (i-1)*3+.5 << " " << (footprint->topR.y-1)-segment*(j+1)-j + heightOffset << endl; // -2
				file << "v " << footprint->topR.x+.1 + widthOffset << " " << (i-1)*3+.5 << " " << (footprint->topR.y-1)-segment*j-j + heightOffset << endl; // -1
				file << "v " << footprint->topR.x+.1 + widthOffset << " " << i*3-.5 << " " << (footprint->topR.y-1)-segment*j-j + heightOffset << endl; // -1
				file << "vn 6 0 0" << endl;
				file << "vt 0 0" << endl; // -4
				file << "vt 0 1" << endl; // -3
				file << "vt " << abs(footprint->topR.y - footprint->botR.y)/(3*data.rightWindows) << " 1" << endl; // -2
				file << "vt " << abs(footprint->topR.y - footprint->botR.y)/(3*data.rightWindows) << " 0" << endl; // -2
				file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			}
		}

		//Front
		file << "v " << footprint->topR.x + widthOffset << " " << i*3 << " " << footprint->topR.y + heightOffset << endl; // -1
		file << "v " << footprint->topR.x + widthOffset << " " << (i-1)*3 << " " << footprint->topR.y + heightOffset << endl; // -1
		file << "v " << footprint->topL.x + widthOffset << " " << (i-1)*3 << " " << footprint->topL.y + heightOffset << endl; // -4
		file << "v " << footprint->topL.x + widthOffset << " " << i*3 << " " << footprint->topL.y + heightOffset << endl; // -4
		file << "vn 0 0 " << 2*texture << endl;
		file << "vt 0 0" << endl; // -4
		file << "vt 0 1" << endl; // -3
		file << "vt " << abs(footprint->topR.x - footprint->topL.x)/3 << " 1" << endl; // -2
		file << "vt " << abs(footprint->topR.x - footprint->topL.x)/3 << " 0" << endl; // -2
		file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			
		if (data.frontWindows != 0)
		{
			int length = abs(footprint->topL.x - footprint->topR.x)-2; //Wall length minus end buffer
			float segment = (float)length/(float)data.frontWindows-(data.frontWindows-1)*(1.0/data.frontWindows); //Divide into sections and subtract buffer
				
			for (int j = 0; j < data.frontWindows; j++)
			{
				file << "v " << (footprint->topR.x-1) - segment*j-j + widthOffset << " " << i*3-.5 << " " << footprint->topR.y+.1 + heightOffset << endl; // -1
				file << "v " << (footprint->topR.x-1) - segment*j-j + widthOffset << " " << (i-1)*3+.5 << " " << footprint->topR.y+.1 + heightOffset << endl; // -1
				file << "v " << (footprint->topR.x-1) - segment*(j+1)-j + widthOffset << " " << (i-1)*3+.5 << " " << footprint->topL.y+.1 + heightOffset << endl; // -4
				file << "v " << (footprint->topR.x-1) - segment*(j+1)-j + widthOffset << " " << i*3-.5 << " " << footprint->topL.y+.1 + heightOffset << endl; // -4
				file << "vn 0 0 6" << endl;
				file << "vt 0 0" << endl; // -4
				file << "vt 0 1" << endl; // -3
				file << "vt " << abs(footprint->topR.x - footprint->topL.x)/(3*data.frontWindows) << " 1" << endl; // -2
				file << "vt " << abs(footprint->topR.x - footprint->topL.x)/(3*data.frontWindows) << " 0" << endl; // -2
				file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			}
		}
		//Back		
		file << "v " << footprint->botL.x + widthOffset << " " << i*3 << " " << footprint->botL.y + heightOffset << endl; // -3
		file << "v " << footprint->botL.x + widthOffset << " " << (i-1)*3 << " " << footprint->botL.y + heightOffset << endl; // -3
		file << "v " << footprint->botR.x + widthOffset << " " << (i-1)*3 << " " << footprint->botR.y + heightOffset << endl; // -2
		file << "v " << footprint->botR.x + widthOffset << " " << i*3 << " " << footprint->botR.y + heightOffset << endl; // -2
		file << "vn 0 0 " << -3*texture << endl;
		file << "vt 0 0" << endl; // -4
		file << "vt 0 1" << endl; // -3
		file << "vt " << abs(footprint->topR.x - footprint->topL.x)/3 << " 1" << endl; // -2
		file << "vt " << abs(footprint->topR.x - footprint->topL.x)/3 << " 0" << endl; // -2
		file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
						
		if (data.backWindows != 0)
		{
			int length = abs(footprint->botL.x - footprint->botR.x)-2; //Wall length minus end buffer
			float segment = (float)length/(float)data.backWindows-(data.backWindows-1)*(1.0/data.backWindows); //Divide into sections and subtract buffer
				
			for (int j = 0; j < data.backWindows; j++)
			{
				file << "v " << (footprint->botR.x-1) - segment*(j+1)-j + widthOffset << " " << i*3-.5 << " " << footprint->botR.y-.1 + heightOffset << endl; // -1
				file << "v " << (footprint->botR.x-1) - segment*(j+1)-j + widthOffset << " " << (i-1)*3+.5 << " " << footprint->botR.y-.1 + heightOffset << endl; // -1
				file << "v " << (footprint->botR.x-1) - segment*j-j + widthOffset << " " << (i-1)*3+.5 << " " << footprint->botL.y-.1 + heightOffset << endl; // -4
				file << "v " << (footprint->botR.x-1) - segment*j-j + widthOffset << " " << i*3-.5 << " " << footprint->botL.y-.1 + heightOffset << endl; // -4
				file << "vn 0 0 -6" << endl;
				file << "vt 0 0" << endl; // -4
				file << "vt 0 1" << endl; // -3
				file << "vt " << abs(footprint->topR.x - footprint->topL.x)/(3*data.backWindows) << " 1" << endl; // -2
				file << "vt " << abs(footprint->topR.x - footprint->topL.x)/(3*data.backWindows) << " 0" << endl; // -2
				file << "f -1/-1/-1 -2/-2/-1 -3/-3/-1 -4/-4/-1" << endl;
			}
		}
#pragma endregion
			if (i == 1)
			{
				footprint = footprint->next;
				footprintCount++;
			}
			else
			{
				footprintPos++;
				if (footprintPos < footprintCount)
				{
					footprint = footprint->next;
				}
				else
				{
					footprint = NULL;
				}
				
			}
		}
		i++;

		//srand(time(NULL));
		//randFall = (rand() % (int)(100)); //Random between 0 and 99 (Percent)
		randFall += floorThreshold;
		if (rate != NULL && (randFall  > 99))
		{
			srand(time(NULL));
			randFall = (rand() % (int) 100);;

			int whichEnd = 0;

			float j = 0;
			int start = 0;
			if(rate->intVal == 0)
			{
				j = rate->floatVal;
			}
			else
			{
				srand(time(NULL));
				j = (rand() % (int)((rate->floatVal2 - rate->floatVal)+1)) + rate->floatVal;
				start = j;
			}


			if (j < 0)
			{
				whichEnd = 2;
				j = -j;
			}
			else if (j < 1 && j > 0)
			{
				whichEnd = 1;
				j*=100;
			}

			while (j > 0 && (whichEnd < 2 || rate->intVal == 1 || rate->intVal == 2 || rate->intVal == 4))
			{
				if (original->next != NULL)
					original = original->next;
				footprintCount--;
				j--;
			}
			if (whichEnd == 1)
			{
				j = rate->floatVal*100;
			}

			if (rate->intVal == 1)
			{
				j = start;
			}
			else if (rate->intVal == 4)
			{
				srand(time(NULL));
				j = (rand() % (int)((rate->floatVal2 - rate->floatVal)+1)) + rate->floatVal;
			}

			while (j > 0 && (whichEnd > 0 || rate->intVal == 1 || rate->intVal == 3 || rate->intVal == 4))
			{
				footprint = original;
				int q = 0;
				while(q == 0)
				{
					if (footprint->next->next != NULL)
					{
						footprint = footprint->next;
					}
					else
					{
						footprintCount--;
						//footprint->next = NULL;
						q = 1;
					}
				}
				j--;

			}

			rate = rate->next;
		}
		footprint = original; 
	}
	file.close();
}

void App::GenerateBuilding()
{
	App::fileData data;
	App::baseUnit footprint;
	data = ReadFile("building.txt");
	App::buildingData * building;
	building = &data.building;
	while (building != NULL)
	{
		building->footprint = GenerateFootprint(*building);
		RemoveDuplicates(building->footprint);
		building = building->next;
	}	

	//This makes sure the file is empty. It clears any old data. 
	ofstream file("building.obj");
	file.close();
	
	building = &data.building;
	int buildingCount = 0;
	while (building != NULL)
	{
		building = building->next;
		buildingCount++;
	}

	building = &data.building;
	int nextStep = 0;
	srand (time(NULL));
	for (int i = -data.world.worldWidth/2; i < (data.world.worldWidth+1)/2; i++)
	{
		for (int j = -data.world.worldHeight/2; j < (data.world.worldHeight+1)/2; j++)
		{
			nextStep = (rand() % (int)(buildingCount + 1));
			while (nextStep > 0 && building->next != NULL)
			{
				nextStep--;
				building = building->next;
			}

			
//			MakeGround("building.obj", (i+1)*data.world.blockWidth-building->width,(j+1)*data.world.blockHeight-building->height, (i)*data.world.blockWidth-building->width,(j)*data.world.blockHeight-building->height);
			MakeGround("building.obj", (i+1)*data.world.blockWidth-10,(j+1)*data.world.blockHeight-10, (i)*data.world.blockWidth-10,(j)*data.world.blockHeight-10);
//			MakeGround("building.obj", 500,500, -500,-500);
			RenderShape(*building, "building.obj", i*data.world.blockWidth,j*data.world.blockHeight);	
			building = &data.building;
		}
	}
}

void App::Refresh()
{
	GenerateBuilding();
	LoadModel();   
}

void App::LoadModel()
{
	ArticulatedModel::Specification spec;
	//spec.filename = System::findDataFile("building.obj");
	spec.scale = 0.15f;
	spec.filename = System::findDataFile("box.obj");
    spec.stripMaterials = true;
	
    model = ArticulatedModel::create(spec);

	spec.filename = System::findDataFile("building.obj");
	spec.scale = 0.15f;
	//spec.filename = System::findDataFile("box.obj");
    spec.stripMaterials = true;
	
    model = ArticulatedModel::create(spec);
}

void App::onInit() {
	
	//Refresh();
    createDeveloperHUD();
    window()->setCaption("CS 334: Pen and Ink / Procedural Modeling - Nathan Tornquist");
        
    ArticulatedModel::Specification spec;
		
	//spec.filename = System::findDataFile("building.obj");
	//spec.scale = 0.15f;
	spec.filename = System::findDataFile("box.obj");
    spec.stripMaterials = true;
    model = ArticulatedModel::create(spec);
	
    /*
	spec.filename = System::findDataFile("teapot/teapot.obj");
    spec.scale = 0.015f;
    spec.stripMaterials = true;
    spec.preprocess.append(ArticulatedModel::Instruction(Any::parse("setCFrame(root(), Point3(0, -0.5, 0));")));
	*/
	/*spec.filename = System::findDataFile("viper/Viper-mk-IV-fighter.obj");
    spec.scale = 0.06f;
    spec.stripMaterials = true;
    spec.preprocess.append(ArticulatedModel::Instruction(Any::parse("setCFrame(root(), CFrame::fromXYZYPRDegrees(0,0,0,-90));")));*/

    makeLighting();
    makeColorList();
	makeBuildingList();
    makeGui();
	loadTextures();

    // Last color is white
    specularColorIndex = colorList.size() - 1;

	// Color 1 is red
    diffuseColorIndex = specularColorIndex;

    m_debugCamera->setPosition(Vector3(1.0f, 1.0f, 2.5f));
    m_debugCamera->setFieldOfView(45 * units::degrees(), FOVDirection::VERTICAL);
    m_debugCamera->lookAt(Point3::zero());

    // Add axes for dragging and turning the model
    manipulator = ThirdPersonManipulator::create();
    addWidget(manipulator);

    // Turn off the default first-person camera controller and developer UI
    m_debugController->setEnabled(false);
    developerWindow->setVisible(false);
    developerWindow->cameraControlWindow->setVisible(false);
    showRenderingStats = false;
}

void App::onGraphics3D(RenderDevice* rd, Array<shared_ptr<Surface> >& surface3D) {
	bool initialDraw_noControls = true;
	bool initialDraw_Controls = true;
	bool texturedDraw = showTextures;
	bool edgeDraw = showEdges;

	int width = rd->width();
	int height = rd->height();
	GLbyte * data = (GLbyte *)malloc( width * height * 4 );
	GLbyte * dataTwo = (GLbyte *)malloc( width * height * 4 );
	GLbyte * newData = (GLbyte *)malloc( width * height * 4);
	//GLbyte * skyBoxData = (GLbyte *)malloc( width * height * 4);

#pragma region InitialDraw_NoShadow_NoControls
	if (initialDraw_noControls){
    rd->clear();
	
    rd->pushState(m_frameBuffer); {
        rd->clear();

        rd->setProjectionAndCameraMatrix(m_debugCamera->projection(), m_debugCamera->frame());
        
        //Draw::skyBox(rd, environment.environmentMapArray[0].texture, environment.environmentMapArray[0].constant);
        
        rd->pushState(); {
            Array< shared_ptr<Surface> > mySurfaces;
            // Pose our model based on the manipulator axes
            model->pose(mySurfaces, manipulator->frame());
            
            // Set up shared arguments
            Args args;
            configureShaderArgs(args);
            
            // Send model geometry to the graphics card
            CFrame cframe;
            for (int i = 0; i < mySurfaces.size(); ++i) {

                // Downcast to UniversalSurface to access its fields
                shared_ptr<UniversalSurface> surface = dynamic_pointer_cast<UniversalSurface>(mySurfaces[i]);
                if (notNull(surface)) {
                    surface->getCoordinateFrame(cframe);
                    rd->setObjectToWorldMatrix(cframe);
                    surface->gpuGeom()->setShaderArgs(args);

                    // (If you want to manually set the material properties and vertex attributes
                    // for shader args, they can be accessed from the fields of the gpuGeom.)
                    LAUNCH_SHADER("myprog.*", args);
                }
            }
        } rd->popState();
        
        // Render other objects, e.g., the 3D widgets
        //Surface::render(rd, m_debugCamera->frame(), m_debugCamera->projection(), surface3D, surface3D, environment);   
    } rd->popState();

    // Perform gamma correction, bloom, and SSAA, and write to the native window frame buffer
    m_film->exposeAndRender(rd, m_debugCamera->filmSettings(), m_colorBuffer0, 1);
	}
#pragma endregion 


	//EDGE DETECTION
	

	
	if( data ) {
	    glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
	    //glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, newData);
	}
	if (newData) {
		int i = 0;
		while (i < width * height * 4)
		{
			newData[i] = 0;
			i++;
		}
	}
	
#pragma region InitialDraw_Controls_NoSkyBox
	if (initialDraw_Controls)
	{
    rd->clear();
	
    rd->pushState(m_frameBuffer); {
        rd->clear();

        rd->setProjectionAndCameraMatrix(m_debugCamera->projection(), m_debugCamera->frame());
        
        //Draw::skyBox(rd, environment.environmentMapArray[0].texture, environment.environmentMapArray[0].constant);
        
        rd->pushState(); {
            Array< shared_ptr<Surface> > mySurfaces;
            // Pose our model based on the manipulator axes
            model->pose(mySurfaces, manipulator->frame());
            
            // Set up shared arguments
            Args args;
            configureShaderArgs(args);
            
            // Send model geometry to the graphics card
            CFrame cframe;
            for (int i = 0; i < mySurfaces.size(); ++i) {

                // Downcast to UniversalSurface to access its fields
                shared_ptr<UniversalSurface> surface = dynamic_pointer_cast<UniversalSurface>(mySurfaces[i]);
                if (notNull(surface)) {
                    surface->getCoordinateFrame(cframe);
                    rd->setObjectToWorldMatrix(cframe);
                    surface->gpuGeom()->setShaderArgs(args);

                    // (If you want to manually set the material properties and vertex attributes
                    // for shader args, they can be accessed from the fields of the gpuGeom.)
                    LAUNCH_SHADER("myprog.*", args);
                }
            }
        } rd->popState();
        
        // Render other objects, e.g., the 3D widgets
        Surface::render(rd, m_debugCamera->frame(), m_debugCamera->projection(), surface3D, surface3D, environment);   
    } rd->popState();

    // Perform gamma correction, bloom, and SSAA, and write to the native window frame buffer
    m_film->exposeAndRender(rd, m_debugCamera->filmSettings(), m_colorBuffer0, 1);
	}
#pragma endregion 

	if( dataTwo ) {
	    glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, dataTwo);
	    //glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, newData);
	}

#pragma region FullDraw_Texture_Controls
	if (texturedDraw){
	rd->clear();
	
    rd->pushState(m_frameBuffer); {
        rd->clear();

        rd->setProjectionAndCameraMatrix(m_debugCamera->projection(), m_debugCamera->frame());
        
        Draw::skyBox(rd, environment.environmentMapArray[0].texture, environment.environmentMapArray[0].constant);
        //Draw::skyBox(rd, glass0, environment.environmentMapArray[0].constant);
        
		/*if (skyBoxData)
		{
			glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,skyBoxData);
			int i = 0;
			int red = 0;
			int blue = 0;
			int green = 0;
			int average = 0;
			while (i < width * height * 4)
			{
				red = newData[i];
				blue = newData[i+1];
				green = newData[i+2];
				average = sqrt((double)(red*red+green*green+blue*blue));
				newData[i] = average;
				newData[i+1] = average;
				newData[i+2] = average;
				i+=4;
			}
			
			glDrawPixels(width,height,GL_RGBA,GL_UNSIGNED_BYTE,skyBoxData);
		}*/

        rd->pushState(); {
            Array< shared_ptr<Surface> > mySurfaces;
            // Pose our model based on the manipulator axes
            model->pose(mySurfaces, manipulator->frame());
            
            // Set up shared arguments
            Args args;
            configureShaderArgs(args);
            
            // Send model geometry to the graphics card
            CFrame cframe;
            for (int i = 0; i < mySurfaces.size(); ++i) {

                // Downcast to UniversalSurface to access its fields
                shared_ptr<UniversalSurface> surface = dynamic_pointer_cast<UniversalSurface>(mySurfaces[i]);
                if (notNull(surface)) {
                    surface->getCoordinateFrame(cframe);
                    rd->setObjectToWorldMatrix(cframe);
                    surface->gpuGeom()->setShaderArgs(args);

                    // (If you want to manually set the material properties and vertex attributes
                    // for shader args, they can be accessed from the fields of the gpuGeom.)
                    LAUNCH_SHADER("textures.*", args);
                }
            }
        } rd->popState();
        
        // Render other objects, e.g., the 3D widgets
        Surface::render(rd, m_debugCamera->frame(), m_debugCamera->projection(), surface3D, surface3D, environment);   
    } rd->popState();

    // Perform gamma correction, bloom, and SSAA, and write to the native window frame buffer
    m_film->exposeAndRender(rd, m_debugCamera->filmSettings(), m_colorBuffer0, 1);
	}
#pragma endregion

#pragma region Gaussian Edge Detection
	if (edgeDraw){
	if (data && newData && dataTwo){
		int i = 0;
		int wPos = 0;
		int hPos = 0;
		float deltaR = 0;
		float deltaG = 0;
		float deltaB = 0;
		float deltaR2 = 0;
		float deltaG2 = 0;
		float deltaB2 = 0;
		float mag;
		float magTwo;
		int changed = 0;
		float delta = edgeThresh;//200;
		while (i < width * height * 4)
		{
			if (wPos != 0)
			{
				deltaR = abs(data[i] - data[4*(wPos-1+hPos*width)]);
				deltaG = abs(data[i+1] - data[4*(wPos-1+hPos*width)+1]);
				deltaB = abs(data[i+2] - data[4*(wPos-1+hPos*width)+2]);

				deltaR2 = abs(dataTwo[i] - dataTwo[4*(wPos-1+hPos*width)]);
				deltaG2 = abs(dataTwo[i+1] - dataTwo[4*(wPos-1+hPos*width)+1]);
				deltaB2 = abs(dataTwo[i+2] - dataTwo[4*(wPos-1+hPos*width)+2]);
							
				mag = deltaR*deltaR + deltaG*deltaG + deltaB*deltaB;
				magTwo = deltaR2*deltaR2 + deltaG2*deltaG2 + deltaB2*deltaB2;

				if (mag > delta && magTwo > delta)
				{
					changed = 1;
				}
			}
			if (wPos != width-1 && changed == 0)
			{
				deltaR = data[i] - data[4*(wPos+1+hPos*width)];
				deltaG = data[i+1] - data[4*(wPos+1+hPos*width)+1];
				deltaB = data[i+2] - data[4*(wPos+1+hPos*width)+2];

				deltaR2 = dataTwo[i] - dataTwo[4*(wPos+1+hPos*width)];
				deltaG2 = dataTwo[i+1] - dataTwo[4*(wPos+1+hPos*width)+1];
				deltaB2 = dataTwo[i+2] - dataTwo[4*(wPos+1+hPos*width)+2];
				
				mag = deltaR*deltaR + deltaG*deltaG + deltaB*deltaB;
				magTwo = deltaR2*deltaR2 + deltaG2*deltaG2 + deltaB2*deltaB2;

				if (mag > delta && magTwo > delta)
				{
					changed = 1;
				}
			}
			if (hPos != 0 && changed == 0)
			{
				deltaR = data[i] - data[4*(wPos+(hPos-1)*width)];
				deltaG = data[i+1] - data[4*(wPos+(hPos-1)*width)+1];
				deltaB = data[i+2] - data[4*(wPos+(hPos-1)*width)+2];

				deltaR2 = dataTwo[i] - dataTwo[4*(wPos+(hPos-1)*width)];
				deltaG2 = dataTwo[i+1] - dataTwo[4*(wPos+(hPos-1)*width)+1];
				deltaB2 = dataTwo[i+2] - dataTwo[4*(wPos+(hPos-1)*width)+2];
				
				mag = deltaR*deltaR + deltaG*deltaG + deltaB*deltaB;
				magTwo = deltaR2*deltaR2 + deltaG2*deltaG2 + deltaB2*deltaB2;

				if (mag > delta && magTwo > delta)
				{
					changed = 1;
				}
			}
			if (hPos != height-1 && changed == 0)
			{
				deltaR = data[i] - data[4*(wPos+(hPos+1)*width)];
				deltaG = data[i+1] - data[4*(wPos+(hPos+1)*width)+1];
				deltaB = data[i+2] - data[4*(wPos+(hPos+1)*width)+2];

				deltaR2 = dataTwo[i] - dataTwo[4*(wPos+(hPos+1)*width)];
				deltaG2 = dataTwo[i+1] - dataTwo[4*(wPos+(hPos+1)*width)+1];
				deltaB2 = dataTwo[i+2] - dataTwo[4*(wPos+(hPos+1)*width)+2];
				
				mag = deltaR*deltaR + deltaG*deltaG + deltaB*deltaB;
				magTwo = deltaR2*deltaR2 + deltaG2*deltaG2 + deltaB2*deltaB2;

				if (mag > delta && magTwo > delta)
				{
					changed = 1;
				}
			}
			if (changed == 0){
				newData[i+3] = 0;
			}
			else
			{
				newData[i] = 100;
				newData[i+1] = 100;
				newData[i+2] = 100;
				newData[i+3] = 255;
			}
			i+=4;

			//Keep Track of Row and Column
			wPos += 1;
			if (wPos >= width)
			{
				wPos = 0;
				hPos++;
			}
			changed = 0;
		}
		
		glEnable(GL_ALPHA_TEST);
		glAlphaFunc( GL_GREATER, 0.5 );
		glDrawPixels(width,height,GL_RGBA,GL_UNSIGNED_BYTE,newData);
		
	}
	free(data);
	free(newData);
	free(dataTwo);
	}
#pragma endregion
}
    
    
void App::configureShaderArgs(Args& args) {
    const shared_ptr<Light>&  light   = environment.lightArray[0];
    const Color3&       diffuseColor  = colorList[diffuseColorIndex].element(0).color(Color3::white()).rgb();
    const Color3&       specularColor = colorList[specularColorIndex].element(0).color(Color3::white()).rgb();
    
    
    // Viewer
    args.setUniform("wsEyePosition",       m_debugCamera->frame().translation);
    
    // Lighting
    args.setUniform("wsLightPos",          light->position().xyz());
    args.setUniform("wsLightDir",          light->position().xyz().direction());
    args.setUniform("lightColor",          light->color);
    args.setUniform("ambient",             Color3(0.3f));
    args.setUniform("environmentMap",      environment.environmentMapArray[0].texture);
    args.setUniform("environmentConstant", environment.environmentMapArray[0].constant);
    
    // UniversalMaterial
    args.setUniform("diffuseColor",        diffuseColor);
    args.setUniform("diffuseScalar",       diffuseScalar);
    
    args.setUniform("specularColor",       specularColor);
    args.setUniform("specularScalar",      specularScalar);
    
    args.setUniform("shine",               shine);
    args.setUniform("reflect",             reflect);

	args.setUniform("bumpMap",             bumpMap);

	args.setUniform("vert1",vert1);
	args.setUniform("vert2",vert2);
	args.setUniform("vert3",vert3);
	args.setUniform("brick0",brick0);
	args.setUniform("brick1",brick1);
	args.setUniform("brick2",brick2);
	args.setUniform("brick3",brick3);
	args.setUniform("brick4",brick4);
	args.setUniform("roof0",roof0);
	args.setUniform("roof1",roof1);
	args.setUniform("roof2",roof2);
	args.setUniform("roof3",roof3);
	args.setUniform("roof4",roof4);
	args.setUniform("glass0",glass0);
	args.setUniform("glass1",glass1);
	args.setUniform("glass2",glass2);
	args.setUniform("glass3",glass3);
	args.setUniform("glass4",glass4);
	args.setUniform("road",road);
}


void App::makeColorList() {
    shared_ptr<GFont> iconFont = GFont::fromFile(System::findDataFile("icon.fnt"));

    // Characters in icon font that make a solid block of color
    static const char* block = "gggggg";

    float size = 18;
    int N = 10;
    colorList.append(GuiText(block, iconFont, size, Color3::black(), Color4::clear()));
    for (int i = 0; i < N; ++i) {
        colorList.append(GuiText(block, iconFont, size, Color3::rainbowColorMap((float)i / N), Color4::clear()));
    }
    colorList.append(GuiText(block, iconFont, size, Color3::white(), Color4::clear()));
}

void App::makeBuildingList() {
    
	buildingList.append("Large City");
    buildingList.append("Manhattan Tall");
	buildingList.append("Manhattan Short");
	buildingList.append("L Fallout");
	buildingList.append("Colosseum");
    buildingList.append("Circle Rates");
    buildingList.append("Center Rotation");
    buildingList.append("2x2 Fallout");   
    
}


void App::LoadExample()
{
	string fileName;
	switch(buildingExample)
	{
	case 0:
		fileName = "examples/large_city.obj";
		break;
	case 1:
		fileName = "examples/manhattan_tall.obj";
		break;
	case 2:
		fileName = "examples/manhattan_short.obj";
		break;
	case 3:
		fileName = "examples/L_fallout.obj";
		break;
	case 4:
		fileName = "examples/colosseum.obj";
		break;
	case 5:
		fileName = "examples/circle_rates.obj";
		break;
	case 6:
		fileName = "examples/centerRot_strange.obj";
		break;
	case 7:
		fileName = "examples/2x2_fallout.obj";
		break;
	default:
		fileName = "building.obj";
		break;
	}
	ArticulatedModel::Specification spec;
	spec.filename = System::findDataFile(fileName);
	spec.scale = 0.15f;
    spec.stripMaterials = true;
    model = ArticulatedModel::create(spec);
}


void App::makeGui() {
    /*shared_ptr<GuiWindow> gui = GuiWindow::create("UniversalMaterial Parameters");    
    GuiPane* pane = gui->pane();

    pane->beginRow();
    pane->addSlider("Lambertian", &diffuseScalar, 0.0f, 1.0f);
    pane->addDropDownList("", colorList, &diffuseColorIndex)->setWidth(80);
    pane->endRow();

    pane->beginRow();
    pane->addSlider("Glossy",    &specularScalar, 0.0f, 1.0f);
    pane->addDropDownList("", colorList, &specularColorIndex)->setWidth(80);
    pane->endRow();
    
    pane->addSlider("Mirror",       &reflect, 0.0f, 1.0f);
    pane->addSlider("Smoothness",   &shine, 1.0f, 100.0f);
    pane->addSlider("Bumpiness",    &bumpiness, 0.0f, 1.0f);
    
    gui->pack();
    //addWidget(gui);
    gui->moveTo(Point2(10, 10));*/

	shared_ptr<GuiWindow> gui = GuiWindow::create("Building Logic");    
	GuiPane* pane = gui->pane();

	//pane->addCheckBox("3D Enabled",&enable3d);
	//pane->addCheckBox("Toggle to Reload",&reloadBool);
	pane->beginRow();
	pane->addButton("Rebuild Model", this, &App::Refresh)->setWidth(120);
	pane->addButton("Reload Model", this, &App::LoadModel)->setWidth(120);
	pane->endRow();
	//pane->beginRow();
	//pane->addLabel("Edge Threshold");
	//pane->addNumberBox("",&edgeThresh,"",G3D::GuiTheme.LINEAR_SLIDER,0,500,1);
	//pane->endRow();

	pane->beginRow();
	pane->addCheckBox("Texture Map",&showTextures)->setWidth(120);
	pane->addCheckBox("Show Edges",&showEdges)->setWidth(120);
	pane->endRow();

	pane->beginRow();
	pane->addDropDownList("Example: ",buildingList,&buildingExample)->setWidth(200);
	pane->addButton("Load",this,&App::LoadExample)->setWidth(40);
	pane->endRow();

	gui->pack();
    addWidget(gui);
    gui->moveTo(Point2(10, 10));
}

void App::makeLighting() {
    environment.lightArray.append(Light::directional("Light", Vector3(1.0f, 1.0f, 1.0f), Color3(1.0f), false));

    // The environmentMap is a cube of six images that represents the incoming light to the scene from
    // the surrounding environment.  G3D specifies all six faces at once using a wildcard and loads
    // them into an OpenGL cube map.
 
    Texture::Specification environmentMapTexture;
    environmentMapTexture.filename   = FilePath::concat(System::findDataFile("world"), "world_*.png");
    
    environmentMapTexture.dimension  = Texture::DIM_CUBE_MAP;
    environmentMapTexture.settings   = Texture::Settings::cubeMap();
    environmentMapTexture.preprocess = Texture::Preprocess::gamma(2.1f);
    // Reduce memory size required to work on older GPUs
    environmentMapTexture.preprocess.scaleFactor = 0.25f;
    environmentMapTexture.settings.interpolateMode = Texture::BILINEAR_NO_MIPMAP;
    
    environment.environmentMapArray.append(Texture::create(environmentMapTexture), 1.0f);
}

void App::loadTextures() {
	
	// load a standard grayscale image, and use preprocess tools to convert it to a normalmap
	bumpMap = Texture::fromFile("heightMap.png", ImageFormat::RGBA8(), Texture::DIM_2D_NPOT, 
		Texture::Settings::defaults(), Texture::Preprocess::normalMap());

	// how to load a regular texture...
	vert1 = Texture::fromFile("vert1.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	vert2 = Texture::fromFile("vert2.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	vert3 = Texture::fromFile("vert3.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	brick0 = Texture::fromFile("brick0.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	brick1 = Texture::fromFile("brick1.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	brick2 = Texture::fromFile("brick2.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	brick3 = Texture::fromFile("brick3.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	brick4 = Texture::fromFile("brick4.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	roof0 = Texture::fromFile("roof0.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	roof1 = Texture::fromFile("roof1.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	roof2 = Texture::fromFile("roof2.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	roof3 = Texture::fromFile("roof3.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	roof4 = Texture::fromFile("roof4.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	glass0 = Texture::fromFile("glass0.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	glass1 = Texture::fromFile("glass1.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	glass2 = Texture::fromFile("glass2.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	glass3 = Texture::fromFile("glass3.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	glass4 = Texture::fromFile("glass4.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
	road = Texture::fromFile("road.png", ImageFormat::RGB8(), Texture::DIM_2D_NPOT);
}

G3D_START_AT_MAIN();

int main(int argc, const char* argv[]) {
    initGLG3D();

#   ifdef G3D_WINDOWS
      if (! FileSystem::exists("myprog.pix", false) && FileSystem::exists("G3D.sln", false)) {
          // The program was started from within Visual Studio and is
          // running with cwd = G3D/VC10/.  Change to
          // the appropriate sample directory.
          chdir("../samples/starter/data-files");
      } else if (FileSystem::exists("data-files")) {
          chdir("data-files");
      }
#   endif

    GApp::Settings settings(argc, argv);  
    settings.colorGuardBandThickness  = Vector2int16(0, 0);
    settings.depthGuardBandThickness  = Vector2int16(0, 0);

    return App(settings).run();
}
